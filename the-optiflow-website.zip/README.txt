
The new website for my brand new project. The Optiflow project for database and inventory management for small stores/businesses. 

I write HTML, CSS , Javascript, PHP on Atom or Geany. 

Please enjoy!
